import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import { resolve } from 'url';
import { reject } from 'q';
import { setTimeout } from 'timers';


@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styles: []
})
export class DataComponent {

  forma: FormGroup;

  usuario: Object = {
    nombrecompleto: {
      nombre: 'Fernando',
      apellido: 'Herrera'
    },
    correo: 'fernando.herrera85@gmail.com',
    // pasatiempos: ['Correr', 'Dormir', 'Comer']  // <-- Objeto nuevo
  };

  constructor() {
    // console.log(this.usuario);
    this.forma = new FormGroup({
      'nombrecompleto' : new FormGroup({
        'nombre': new FormControl('', [
                                        Validators.required,
                                        Validators.minLength(3)
                                  ]),
        'apellido': new FormControl('', Validators.required),
      }),
      'correo': new FormControl('', [
                                      Validators.required,
                                      Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')
                                ]),
      'pasatiempos': new FormArray([
        new FormControl('', [Validators.required,
                              this.pasaTiempoRequerido
                            ])
      ]),
      'username': new FormControl('', Validators.required, this.existeUsuario),
      'password1': new FormControl('', Validators.required),
      'password2': new FormControl()
    });

    // Con esto seteo los valores por defecto (si es que lo deseo)
    // this.forma.setValue( this.usuario );

    this.forma.controls['password2'].setValidators([
      Validators.required,
      this.noIgual.bind(this.forma) // <-- Se usa bind porque el this esta en otro contexto, y con esto se indica que es this.
    ]);

    // this.forma.controls.valueChanges <-- Con esto escucho de todos los objetos
    this.forma.controls['username'].valueChanges // <-- Con esto escucho el de un objeto especifico
      .subscribe(data => {
        console.log(data);
      });

    this.forma.controls['username'].statusChanges // <-- Con esto escucho el status de un objeto especifico
      .subscribe(data => {
        console.log(data);
      });
  }

  agregarPasatiempo() {
    (<FormArray>this.forma.controls['pasatiempos']).push(
      new FormControl('', Validators.required)
    );
  }

  pasaTiempoRequerido(control: FormControl): {[s: string]: boolean } {
    if ( control.value === '') {
      return {
        pasatiempoRequerido: true
      };
    }

    return null;
  }

  noIgual(control: FormControl): { [s: string]: boolean } {
    const forma: any = this;
    if (control.value !== forma.controls['password1'].value) {
      return {
        noiguales: true
      };
    }

    return null;
  }

  // Validacion asyncrona
  existeUsuario(control: FormControl): Promise<any>|Observable<any> {
    const promesa = new Promise(
      // tslint:disable-next-line:no-shadowed-variable
      ( resolve, reject ) => {
        setTimeout(() => {
          if ( control.value === 'strider') {
            resolve( {existe: true} );
          }else {
            resolve( null );
          }
        }, 3000);
      }
    );

    return promesa;
  }

  guardarCambios() {
    console.log(this.forma.value);
    console.log(this.forma);

    // Con esto reseteo los datos del formulario
    // Opcion 1: seteo a los valores por defecto
    // this.forma.reset(this.usuario);

    // Opcion 2: seteo un fomulario limpio
    // this.forma.reset({
    //   nombrecompleto: {
    //     nombre: '',
    //     apellido: ''
    //   },
    //   correo: ''
    // });

    // Opcion 3: setear cada uno de los controles (No recomendable, mucho codigo)
    // this.forma.controls['nombrecompleto.nombre'].setValue('');
    // this.forma.controls['nombrecompleto.apellido'].setValue('');
    // this.forma.controls['correo'].setValue('');

    // Opcion 4: limpiar todos los valores de manera generica:
    // this.forma.reset({});
  }
}
